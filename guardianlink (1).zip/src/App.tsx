import React, { useState, useEffect, createContext, useContext } from 'react';
import { 
  auth, 
  db, 
  googleProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  limit, 
  Timestamp, 
  addDoc,
  User
} from './firebase';
import { 
  LayoutDashboard, 
  Smartphone, 
  Bell, 
  Phone, 
  MessageSquare, 
  MapPin, 
  LogOut, 
  Plus, 
  Battery, 
  Clock,
  ChevronRight,
  ShieldCheck,
  Search,
  AlertCircle,
  Image as ImageIcon,
  FileText,
  Download,
  Eye,
  AppWindow,
  Lock,
  Unlock,
  HelpCircle,
  Settings,
  DownloadCloud,
  CheckCircle2,
  Info,
  RefreshCw,
  History,
  Upload,
  ExternalLink,
  Package,
  Quote
} from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
interface Device {
  id: string;
  deviceName: string;
  model: string;
  osVersion: string;
  parentUid: string;
  lastSeen: any;
  batteryLevel: number;
  locationRefreshInterval?: number;
  lastLocationRequest?: string;
}

interface NotificationData {
  id: string;
  appName: string;
  packageName: string;
  title: string;
  text: string;
  timestamp: any;
}

interface CallLogData {
  id: string;
  number: string;
  name: string;
  type: 'incoming' | 'outgoing' | 'missed';
  duration: number;
  timestamp: any;
}

interface MessageData {
  id: string;
  address: string;
  body: string;
  type: 'inbox' | 'sent';
  timestamp: any;
}

interface LocationData {
  id: string;
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: any;
}

interface FileData {
  id: string;
  fileName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
  isImage: boolean;
  thumbnailUrl?: string;
  downloadUrl?: string;
  timestamp: any;
}

interface AppData {
  id: string;
  appName: string;
  packageName: string;
  version: string;
  isBlocked: boolean;
  iconUrl?: string;
  lastUsed: any;
}

interface InstallRequest {
  id: string;
  appName: string;
  packageName?: string;
  apkUrl: string;
  status: 'pending' | 'downloading' | 'installing' | 'completed' | 'failed';
  timestamp: any;
  errorMessage?: string;
}

// --- Context ---
const AuthContext = createContext<{
  user: User | null;
  loading: boolean;
  signIn: () => Promise<void>;
  logout: () => Promise<void>;
}>({
  user: null,
  loading: true,
  signIn: async () => {},
  logout: async () => {},
});

const useAuth = () => useContext(AuthContext);

// --- Components ---

const ErrorBoundary = ({ children }: { children: React.ReactNode }) => {
  const [hasError, setHasError] = useState(false);
  const [errorInfo, setErrorInfo] = useState<string | null>(null);

  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      if (event.error?.message?.includes('{"error":')) {
        setHasError(true);
        setErrorInfo(event.error.message);
      }
    };
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  if (hasError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-red-50 p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 border border-red-100">
          <div className="flex items-center gap-3 text-red-600 mb-4">
            <AlertCircle size={32} />
            <h2 className="text-2xl font-bold">Security Error</h2>
          </div>
          <p className="text-gray-600 mb-6">
            A permissions error occurred while accessing the database. This usually means your security rules are working as intended to protect data.
          </p>
          <pre className="bg-gray-100 p-4 rounded-lg text-xs overflow-auto max-h-40 mb-6">
            {errorInfo}
          </pre>
          <button 
            onClick={() => window.location.reload()}
            className="w-full py-3 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 transition-colors"
          >
            Restart Application
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

const SidebarItem = ({ 
  icon: Icon, 
  label, 
  active, 
  onClick,
  delay = 0
}: { 
  icon: any, 
  label: string, 
  active?: boolean, 
  onClick: () => void,
  delay?: number
}) => (
  <motion.button
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
    whileHover={{ x: 4 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    className={cn(
      "sidebar-item w-full group relative overflow-hidden",
      active 
        ? "sidebar-item-active" 
        : "sidebar-item-inactive"
    )}
  >
    <Icon size={20} className={cn(
      "transition-transform duration-300 group-hover:scale-110",
      active ? "text-white" : "text-slate-400 group-hover:text-brand-600"
    )} />
    <span className="font-bold tracking-tight">{label}</span>
    {active && (
      <motion.div 
        layoutId="activeTabIndicator"
        className="ml-auto w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_8px_rgba(255,255,255,0.8)]"
      />
    )}
  </motion.button>
);

const StatCard = ({ label, value, icon: Icon, color, delay = 0 }: { label: string, value: string | number, icon: any, color: string, delay?: number }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
    whileHover={{ y: -5 }}
    className="card-modern p-8"
  >
    <div className="flex items-center justify-between mb-6">
      <div className={cn("p-4 rounded-2xl shadow-lg", color)}>
        <Icon size={28} className="text-white" />
      </div>
      <div className="text-right">
        <span className="text-3xl font-black text-slate-900 font-display tracking-tight">{value}</span>
      </div>
    </div>
    <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">{label}</p>
  </motion.div>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);

  const [isChildMode, setIsChildMode] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        setAuthError(null);
        // Ensure user profile exists
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: currentUser.uid,
            email: currentUser.email,
            displayName: currentUser.displayName,
            photoURL: currentUser.photoURL,
            createdAt: new Date().toISOString()
          });
        }
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const signIn = async () => {
    setIsSigningIn(true);
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      console.error("Sign in error:", error);
      if (error.code === 'auth/popup-closed-by-user') {
        setAuthError("Sign-in was cancelled. Please try again.");
      } else if (error.code === 'auth/popup-blocked') {
        setAuthError("Sign-in popup was blocked by your browser. Please allow popups for this site.");
      } else {
        setAuthError("An error occurred during sign-in. Please try again.");
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-indigo-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, loading, signIn, logout }}>
      <ErrorBoundary>
        {!user ? <LoginScreen error={authError} isSigningIn={isSigningIn} /> : (isChildMode ? <ChildApp onExit={() => setIsChildMode(false)} /> : <Dashboard onSwitchToChild={() => setIsChildMode(true)} />)}
      </ErrorBoundary>
    </AuthContext.Provider>
  );
}

function LoginScreen({ error, isSigningIn }: { error: string | null, isSigningIn: boolean }) {
  const { signIn } = useAuth();

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Background Accents */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-brand-100 rounded-full blur-[120px] opacity-50" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-100 rounded-full blur-[120px] opacity-50" />

      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-md w-full glass rounded-[3rem] p-12 text-center relative z-10"
      >
        <motion.div 
          initial={{ scale: 0.8, rotate: -10 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
          className="w-24 h-24 bg-brand-600 rounded-[2rem] flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-brand-200"
        >
          <ShieldCheck size={56} className="text-white" />
        </motion.div>
        
        <h1 className="text-5xl font-black text-slate-900 mb-4 tracking-tight font-display">GuardianLink</h1>
        <p className="text-slate-500 mb-12 text-lg font-medium leading-relaxed">
          The next generation of parental control. Monitor and protect with precision.
        </p>
        
        {error && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-8 p-5 bg-red-50 border border-red-100 rounded-3xl flex items-center gap-4 text-red-600 text-sm font-bold shadow-sm"
          >
            <AlertCircle size={20} className="flex-shrink-0" />
            <p className="text-left leading-snug">{error}</p>
          </motion.div>
        )}

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={signIn}
          disabled={isSigningIn}
          className={cn(
            "w-full flex items-center justify-center gap-4 py-5 bg-slate-900 text-white rounded-[1.5rem] font-bold text-lg transition-all shadow-2xl shadow-slate-200 disabled:opacity-70 disabled:cursor-not-allowed",
            isSigningIn && "animate-pulse"
          )}
        >
          {isSigningIn ? (
            <RefreshCw className="animate-spin" size={24} />
          ) : (
            <img src="https://www.google.com/favicon.ico" alt="Google" className="w-6 h-6" />
          )}
          {isSigningIn ? "Authenticating..." : "Continue with Google"}
        </motion.button>
        
        <div className="mt-12 flex items-center justify-center gap-8">
          <div className="flex flex-col items-center gap-1">
            <div className="w-1.5 h-1.5 bg-brand-500 rounded-full" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Secure</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="w-1.5 h-1.5 bg-brand-500 rounded-full" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Real-time</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="w-1.5 h-1.5 bg-brand-500 rounded-full" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Private</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function Dashboard({ onSwitchToChild }: { onSwitchToChild: () => void }) {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showInstallModal, setShowInstallModal] = useState(false);
  const [devices, setDevices] = useState<Device[]>([]);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [notifications, setNotifications] = useState<NotificationData[]>([]);
  const [callLogs, setCallLogs] = useState<CallLogData[]>([]);
  const [messages, setMessages] = useState<MessageData[]>([]);
  const [locations, setLocations] = useState<LocationData[]>([]);
  const [files, setFiles] = useState<FileData[]>([]);
  const [apps, setApps] = useState<AppData[]>([]);
  const [installRequests, setInstallRequests] = useState<InstallRequest[]>([]);

  // Fetch devices
  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'devices'), orderBy('lastSeen', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const deviceList = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as Device))
        .filter(d => d.parentUid === user.uid);
      setDevices(deviceList);
      if (deviceList.length > 0 && !selectedDevice) {
        setSelectedDevice(deviceList[0]);
      }
    }, (error) => {
      console.error("Device fetch error:", error);
    });
    return () => unsubscribe();
  }, [user]);

  // Fetch data for selected device
  useEffect(() => {
    if (!selectedDevice) return;

    const unsubNotifications = onSnapshot(
      query(collection(db, `devices/${selectedDevice.id}/notifications`), orderBy('timestamp', 'desc'), limit(50)),
      (snap) => setNotifications(snap.docs.map(d => ({ id: d.id, ...d.data() } as NotificationData)))
    );

    const unsubCalls = onSnapshot(
      query(collection(db, `devices/${selectedDevice.id}/callLogs`), orderBy('timestamp', 'desc'), limit(50)),
      (snap) => setCallLogs(snap.docs.map(d => ({ id: d.id, ...d.data() } as CallLogData)))
    );

    const unsubMessages = onSnapshot(
      query(collection(db, `devices/${selectedDevice.id}/messages`), orderBy('timestamp', 'desc'), limit(50)),
      (snap) => setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() } as MessageData)))
    );

    const unsubLocations = onSnapshot(
      query(collection(db, `devices/${selectedDevice.id}/locations`), orderBy('timestamp', 'desc'), limit(10)),
      (snap) => setLocations(snap.docs.map(d => ({ id: d.id, ...d.data() } as LocationData)))
    );

    const unsubFiles = onSnapshot(
      query(collection(db, `devices/${selectedDevice.id}/files`), orderBy('timestamp', 'desc'), limit(50)),
      (snap) => setFiles(snap.docs.map(d => ({ id: d.id, ...d.data() } as FileData)))
    );

    const unsubApps = onSnapshot(
      query(collection(db, `devices/${selectedDevice.id}/apps`), orderBy('appName', 'asc')),
      (snap) => setApps(snap.docs.map(d => ({ id: d.id, ...d.data() } as AppData)))
    );

    const unsubInstallRequests = onSnapshot(
      query(collection(db, `devices/${selectedDevice.id}/installRequests`), orderBy('timestamp', 'desc'), limit(20)),
      (snap) => setInstallRequests(snap.docs.map(d => ({ id: d.id, ...d.data() } as InstallRequest)))
    );

    return () => {
      unsubNotifications();
      unsubCalls();
      unsubMessages();
      unsubLocations();
      unsubFiles();
      unsubApps();
      unsubInstallRequests();
    };
  }, [selectedDevice]);

  const addMockDevice = async () => {
    if (!user) return;
    const deviceId = `mock_${Math.random().toString(36).substr(2, 9)}`;
    const newDevice = {
      deviceId,
      deviceName: "Child's Phone",
      model: "Pixel 7 Pro",
      osVersion: "Android 14",
      parentUid: user.uid,
      lastSeen: new Date().toISOString(),
      batteryLevel: 85,
      locationRefreshInterval: 15
    };
    await setDoc(doc(db, 'devices', deviceId), newDevice);
    
    // Add some mock data
    await addDoc(collection(db, `devices/${deviceId}/notifications`), {
      appName: "WhatsApp",
      packageName: "com.whatsapp",
      title: "Mom",
      text: "Where are you?",
      timestamp: new Date().toISOString()
    });

    await addDoc(collection(db, `devices/${deviceId}/callLogs`), {
      number: "+1 234 567 890",
      name: "Dad",
      type: "incoming",
      duration: 120,
      timestamp: new Date().toISOString()
    });

    await addDoc(collection(db, `devices/${deviceId}/messages`), {
      address: "+1 234 567 890",
      body: "Hey, are you coming home?",
      type: "inbox",
      timestamp: new Date().toISOString()
    });

    await addDoc(collection(db, `devices/${deviceId}/locations`), {
      latitude: 37.7749,
      longitude: -122.4194,
      accuracy: 10,
      timestamp: new Date().toISOString()
    });

    await addDoc(collection(db, `devices/${deviceId}/files`), {
      fileName: "Family_Photo.jpg",
      filePath: "/storage/emulated/0/DCIM/Camera/IMG_2024.jpg",
      fileSize: 2450000,
      mimeType: "image/jpeg",
      isImage: true,
      thumbnailUrl: "https://picsum.photos/seed/family/400/400",
      downloadUrl: "https://picsum.photos/seed/family/1200/800",
      timestamp: new Date().toISOString()
    });

    await addDoc(collection(db, `devices/${deviceId}/files`), {
      fileName: "Homework.pdf",
      filePath: "/storage/emulated/0/Download/Homework.pdf",
      fileSize: 1200000,
      mimeType: "application/pdf",
      isImage: false,
      timestamp: new Date().toISOString()
    });

    await addDoc(collection(db, `devices/${deviceId}/apps`), {
      appName: "Instagram",
      packageName: "com.instagram.android",
      version: "321.0.0.40.108",
      isBlocked: false,
      iconUrl: "https://picsum.photos/seed/instagram/100/100",
      lastUsed: new Date().toISOString()
    });

    await addDoc(collection(db, `devices/${deviceId}/apps`), {
      appName: "TikTok",
      packageName: "com.zhiliaoapp.musically",
      version: "33.8.4",
      isBlocked: true,
      iconUrl: "https://picsum.photos/seed/tiktok/100/100",
      lastUsed: new Date().toISOString()
    });

    await addDoc(collection(db, `devices/${deviceId}/apps`), {
      appName: "YouTube",
      packageName: "com.google.android.youtube",
      version: "19.08.35",
      isBlocked: false,
      iconUrl: "https://picsum.photos/seed/youtube/100/100",
      lastUsed: new Date().toISOString()
    });
  };

  return (
    <div className="flex h-screen bg-[#F8FAFC] overflow-hidden font-sans">
      {/* Sidebar */}
      <motion.aside 
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="w-80 bg-white border-r border-slate-100 flex flex-col z-30 shadow-2xl shadow-slate-200/20"
      >
        <div className="p-8">
          <div className="flex items-center gap-3 mb-10 px-2">
            <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center shadow-lg shadow-brand-100">
              <ShieldCheck size={24} className="text-white" />
            </div>
            <span className="text-xl font-black font-display tracking-tight text-gradient">GuardianLink</span>
          </div>

          <nav className="space-y-2">
            <SidebarItem icon={LayoutDashboard} label="Overview" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} delay={0.1} />
            <SidebarItem icon={Bell} label="Alerts" active={activeTab === 'notifications'} onClick={() => setActiveTab('notifications')} delay={0.15} />
            <SidebarItem icon={Phone} label="Call Logs" active={activeTab === 'calls'} onClick={() => setActiveTab('calls')} delay={0.2} />
            <SidebarItem icon={MessageSquare} label="Messages" active={activeTab === 'messages'} onClick={() => setActiveTab('messages')} delay={0.25} />
            <SidebarItem icon={MapPin} label="Live Location" active={activeTab === 'location'} onClick={() => setActiveTab('location')} delay={0.3} />
            <SidebarItem icon={ImageIcon} label="Gallery & Files" active={activeTab === 'files'} onClick={() => setActiveTab('files')} delay={0.35} />
            <SidebarItem icon={AppWindow} label="App Control" active={activeTab === 'apps'} onClick={() => setActiveTab('apps')} delay={0.4} />
            <SidebarItem icon={HelpCircle} label="Setup Guide" active={activeTab === 'setup'} onClick={() => setActiveTab('setup')} delay={0.45} />
            <SidebarItem icon={Smartphone} label="Child App Demo" onClick={onSwitchToChild} delay={0.5} />
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-slate-50">
          <div className="flex items-center gap-4 mb-6 p-4 bg-slate-50 rounded-2xl border border-slate-100">
            <img 
              src={user?.photoURL || ''} 
              alt={user?.displayName || ''} 
              className="w-10 h-10 rounded-xl border-2 border-white shadow-sm"
              referrerPolicy="no-referrer"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-slate-900 truncate">{user?.displayName}</p>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Parent Account</p>
            </div>
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center justify-center gap-3 px-4 py-3 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-2xl transition-all font-bold text-sm"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Header */}
        <motion.header 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="h-24 bg-white/80 backdrop-blur-md border-b border-slate-100 flex items-center justify-between px-10 sticky top-0 z-20"
        >
          <div className="flex flex-col">
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-black text-slate-900 capitalize font-display tracking-tight">
                {activeTab === 'dashboard' ? 'Overview' : activeTab.replace('-', ' ')}
              </h1>
              <div className="px-3 py-1 bg-brand-50 text-brand-600 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-brand-600 rounded-full animate-pulse" />
                Live
              </div>
            </div>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Monitoring child activity</p>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="relative">
                <select
                  value={selectedDevice?.id || ''}
                  onChange={(e) => setSelectedDevice(devices.find(d => d.id === e.target.value) || null)}
                  className="appearance-none bg-slate-50 border border-slate-100 rounded-2xl px-6 py-3 pr-12 font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500 shadow-sm transition-all hover:bg-slate-100"
                >
                  {devices.length === 0 && <option value="">No devices found</option>}
                  {devices.map(d => (
                    <option key={d.id} value={d.id}>{d.deviceName}</option>
                  ))}
                </select>
                <Smartphone size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
              <button 
                onClick={() => setShowInstallModal(true)}
                className="btn-primary flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white px-6 py-3 rounded-2xl font-bold shadow-lg shadow-brand-100 transition-all"
              >
                <DownloadCloud size={20} />
                Install Child App
              </button>
              <button 
                onClick={addMockDevice}
                className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-6 py-3 rounded-2xl font-bold transition-all"
              >
                <Plus size={20} />
                Add Device
              </button>
            </div>
            <div className="h-8 w-px bg-slate-100 mx-2" />
            <button className="p-3 text-slate-400 hover:text-slate-900 hover:bg-slate-50 rounded-2xl transition-all relative group">
              <Bell size={20} className="group-hover:rotate-12 transition-transform" />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
            </button>
          </div>
        </motion.header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-10 custom-scrollbar relative">
          <div className="max-w-7xl mx-auto">
            {!selectedDevice ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-[3rem] border-2 border-dashed border-slate-100 p-24 text-center shadow-sm"
              >
                <div className="w-24 h-24 bg-slate-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8">
                  <Smartphone size={48} className="text-slate-300" />
                </div>
                <h3 className="text-3xl font-black text-slate-900 mb-4 font-display">No Device Connected</h3>
                <p className="text-slate-500 max-w-md mx-auto mb-10 font-medium text-lg leading-relaxed">
                  Connect a child's device to start monitoring their activity. Use the "Add Device" button to simulate a connection for testing.
                </p>
                <button 
                  onClick={addMockDevice}
                  className="btn-primary"
                >
                  Connect First Device
                </button>
              </motion.div>
            ) : (
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                  className="space-y-10"
                >
                  {activeTab === 'dashboard' && <DashboardView device={selectedDevice} notifications={notifications} calls={callLogs} messages={messages} locations={locations} />}
                  {activeTab === 'notifications' && <NotificationsView notifications={notifications} />}
                  {activeTab === 'calls' && <CallsView calls={callLogs} />}
                  {activeTab === 'messages' && <MessagesView messages={messages} />}
                  {activeTab === 'location' && <LocationView locations={locations} device={selectedDevice} />}
                  {activeTab === 'files' && <FilesView files={files} />}
                  {activeTab === 'apps' && <AppsView apps={apps} installRequests={installRequests} deviceId={selectedDevice.id} />}
                  {activeTab === 'setup' && <SetupGuideView />}
                </motion.div>
              </AnimatePresence>
            )}
          </div>
        </div>
        {/* Modals */}
        <AnimatePresence>
          {showInstallModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowInstallModal(false)}
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative bg-white rounded-[3rem] shadow-2xl w-full max-w-2xl overflow-hidden"
              >
                <div className="p-12">
                  <div className="flex items-center justify-between mb-10">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-brand-100 rounded-2xl flex items-center justify-center">
                        <DownloadCloud size={32} className="text-brand-600" />
                      </div>
                      <div>
                        <h2 className="text-3xl font-black text-slate-900 tracking-tight">Install GuardianLink</h2>
                        <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">On Child's Device</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setShowInstallModal(false)}
                      className="p-3 hover:bg-slate-50 rounded-2xl text-slate-400 transition-all"
                    >
                      <Plus size={24} className="rotate-45" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-10 mb-10">
                    <div className="space-y-6">
                      <div className="flex gap-4">
                        <div className="w-8 h-8 bg-slate-900 text-white rounded-full flex items-center justify-center flex-shrink-0 font-black text-sm">1</div>
                        <div>
                          <p className="font-bold text-slate-900 mb-1">Scan QR Code</p>
                          <p className="text-sm text-slate-500 leading-relaxed">Open the camera on your child's device and scan this code.</p>
                        </div>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-8 h-8 bg-slate-900 text-white rounded-full flex items-center justify-center flex-shrink-0 font-black text-sm">2</div>
                        <div>
                          <p className="font-bold text-slate-900 mb-1">Download APK</p>
                          <p className="text-sm text-slate-500 leading-relaxed">Download and install the GuardianLink agent application.</p>
                        </div>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-8 h-8 bg-slate-900 text-white rounded-full flex items-center justify-center flex-shrink-0 font-black text-sm">3</div>
                        <div>
                          <p className="font-bold text-slate-900 mb-1">Pair Device</p>
                          <p className="text-sm text-slate-500 leading-relaxed">Enter the pairing code shown on the child app to connect.</p>
                        </div>
                      </div>
                    </div>
                    <div className="bg-slate-50 rounded-[2rem] p-8 flex flex-col items-center justify-center border-2 border-dashed border-slate-200">
                      <div className="w-40 h-40 bg-white rounded-3xl shadow-sm border border-slate-100 p-4 mb-6">
                        {/* Simulated QR Code */}
                        <div className="w-full h-full grid grid-cols-8 grid-rows-8 gap-1 opacity-80">
                          {Array.from({ length: 64 }).map((_, i) => (
                            <div key={i} className={cn("rounded-[1px]", Math.random() > 0.5 ? "bg-slate-900" : "bg-transparent")} />
                          ))}
                        </div>
                      </div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Pairing Code</p>
                      <div className="text-3xl font-black text-brand-600 tracking-[0.2em]">GL-8829</div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <button className="flex-1 py-5 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl shadow-slate-200 hover:bg-slate-800 transition-all">
                      <Download size={20} />
                      Download APK
                    </button>
                    <button 
                      onClick={onSwitchToChild}
                      className="flex-1 py-5 bg-brand-50 text-brand-600 border-2 border-brand-100 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-brand-100 transition-all"
                    >
                      <Smartphone size={20} />
                      Open Demo App
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

function ChildApp({ onExit }: { onExit: () => void }) {
  const { user } = useAuth();
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 font-sans">
      <div className="w-full max-w-[400px] aspect-[9/19] bg-slate-900 rounded-[4rem] border-[12px] border-slate-800 shadow-2xl overflow-hidden relative flex flex-col">
        {/* Status Bar */}
        <div className="h-12 flex items-center justify-between px-10 pt-4">
          <span className="text-white font-bold text-sm">{format(time, 'HH:mm')}</span>
          <div className="flex items-center gap-2">
            <RefreshCw size={14} className="text-white/40" />
            <Battery size={16} className="text-emerald-400" />
          </div>
        </div>

        {/* Dynamic Island */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-32 h-8 bg-black rounded-full" />

        <div className="flex-1 flex flex-col p-8 pt-12">
          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-32 h-32 bg-brand-600 rounded-[2.5rem] flex items-center justify-center mb-8 shadow-2xl shadow-brand-900/50"
            >
              <ShieldCheck size={64} className="text-white" />
            </motion.div>
            
            <h2 className="text-3xl font-black text-white mb-4 tracking-tight">Device Protected</h2>
            <p className="text-slate-400 font-medium leading-relaxed mb-12">
              GuardianLink is actively monitoring this device to ensure your safety online.
            </p>

            <div className="w-full space-y-4">
              <div className="bg-slate-800/50 backdrop-blur-md p-6 rounded-3xl border border-white/5 flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center">
                  <CheckCircle2 size={24} className="text-emerald-400" />
                </div>
                <div className="text-left">
                  <p className="text-white font-bold">Live Monitoring</p>
                  <p className="text-xs text-slate-400">System active and reporting</p>
                </div>
              </div>

              <div className="bg-slate-800/50 backdrop-blur-md p-6 rounded-3xl border border-white/5 flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-500/20 rounded-2xl flex items-center justify-center">
                  <Lock size={24} className="text-brand-400" />
                </div>
                <div className="text-left">
                  <p className="text-white font-bold">App Restrictions</p>
                  <p className="text-xs text-slate-400">2 apps currently blocked</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-auto pt-8">
            <button 
              onClick={onExit}
              className="w-full py-5 bg-white text-slate-900 rounded-[2rem] font-black text-sm uppercase tracking-widest hover:bg-slate-100 transition-all"
            >
              Exit Demo Mode
            </button>
            <p className="text-center text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] mt-6">
              GuardianLink v2.4.0
            </p>
          </div>
        </div>

        {/* Home Indicator */}
        <div className="h-1.5 w-32 bg-white/20 rounded-full mx-auto mb-2" />
      </div>
    </div>
  );
}

// --- View Components ---

function DashboardView({ device, notifications, calls, messages, locations }: { 
  device: Device, 
  notifications: NotificationData[], 
  calls: CallLogData[], 
  messages: MessageData[],
  locations: LocationData[]
}) {
  const chartData = [
    { name: 'Mon', count: 12 },
    { name: 'Tue', count: 19 },
    { name: 'Wed', count: 15 },
    { name: 'Thu', count: 22 },
    { name: 'Fri', count: 30 },
    { name: 'Sat', count: 18 },
    { name: 'Sun', count: 10 },
  ];

  return (
    <div className="space-y-10">
      {/* Device Info & Quick Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-1 card-modern p-8 bg-slate-900 text-white relative overflow-hidden group"
        >
          <div className="relative z-10">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md">
                <Smartphone size={24} className="text-white" />
              </div>
              <div>
                <h3 className="text-xl font-black font-display tracking-tight">{device.deviceName}</h3>
                <p className="text-[10px] text-white/40 font-black uppercase tracking-widest">{device.model}</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs">
                <span className="text-white/40 font-black uppercase tracking-widest">OS Version</span>
                <span className="font-black">{device.osVersion}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-white/40 font-black uppercase tracking-widest">Last Seen</span>
                <span className="font-black">{format(new Date(device.lastSeen), 'HH:mm')}</span>
              </div>
              <div className="pt-4 border-t border-white/10">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] text-white/40 font-black uppercase tracking-widest">Battery Status</span>
                  <span className="text-xs font-black">{device.batteryLevel}%</span>
                </div>
                <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${device.batteryLevel}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className={cn(
                      "h-full rounded-full",
                      device.batteryLevel > 20 ? "bg-emerald-500" : "bg-rose-500"
                    )}
                  />
                </div>
              </div>
            </div>
          </div>
          <Smartphone size={140} className="absolute -right-8 -bottom-8 text-white/5 group-hover:scale-110 transition-transform duration-700" />
        </motion.div>

        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-8">
          <StatCard label="Alerts" value={notifications.length} icon={Bell} color="bg-amber-500" delay={0.1} />
          <StatCard label="Calls" value={calls.length} icon={Phone} color="bg-indigo-500" delay={0.2} />
          <StatCard label="Messages" value={messages.length} icon={MessageSquare} color="bg-rose-500" delay={0.3} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Activity Chart */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 card-modern p-10"
        >
          <div className="flex items-center justify-between mb-10">
            <div>
              <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Activity Trends</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Usage patterns over 7 days</p>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 rounded-xl text-xs font-bold text-slate-500">
              <History size={14} />
              Last 7 Days
            </div>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0c8ce9" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#0c8ce9" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 600}} 
                  dy={15} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 600}} 
                />
                <Tooltip 
                  contentStyle={{
                    borderRadius: '24px', 
                    border: 'none', 
                    boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
                    padding: '16px'
                  }}
                  itemStyle={{fontWeight: 800, color: '#0c8ce9'}}
                />
                <Area 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#0c8ce9" 
                  strokeWidth={4} 
                  fillOpacity={1} 
                  fill="url(#colorCount)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Recent Notifications */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card-modern p-10 flex flex-col"
        >
          <div className="flex items-center justify-between mb-10">
            <div>
              <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Recent Alerts</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Latest device notifications</p>
            </div>
            <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600">
              <Bell size={24} />
            </div>
          </div>
          <div className="space-y-8 flex-1">
            {notifications.slice(0, 5).map((n, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                key={n.id} 
                className="flex gap-5 group cursor-pointer"
              >
                <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:bg-brand-50 transition-colors">
                  <Smartphone size={20} className="text-slate-400 group-hover:text-brand-600 transition-colors" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-black text-slate-900 truncate">{n.appName}</p>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">
                      {format(new Date(n.timestamp), 'HH:mm')}
                    </p>
                  </div>
                  <p className="text-xs text-slate-500 font-medium line-clamp-2 leading-relaxed">{n.title}: {n.text}</p>
                </div>
              </motion.div>
            ))}
            {notifications.length === 0 && (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
                  <Bell size={32} className="text-slate-200" />
                </div>
                <p className="text-slate-400 font-bold">No recent alerts</p>
              </div>
            )}
          </div>
          <button className="mt-10 w-full py-4 bg-slate-50 text-slate-600 rounded-2xl font-bold text-sm hover:bg-slate-100 transition-all flex items-center justify-center gap-2">
            View All Alerts
            <ChevronRight size={16} />
          </button>
        </motion.div>
      </div>
    </div>
  );
}

function NotificationsView({ notifications }: { notifications: NotificationData[] }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-modern overflow-hidden"
    >
      <div className="p-8 border-b border-slate-50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Notification History</h3>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">All captured device alerts</p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search apps..." 
            className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl text-sm focus:ring-2 focus:ring-brand-500 font-bold"
          />
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">App</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Content</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {notifications.map((n, idx) => (
              <motion.tr 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                key={n.id} 
                className="hover:bg-slate-50/50 transition-colors group"
              >
                <td className="px-8 py-6">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-brand-50 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Smartphone size={18} className="text-brand-600" />
                    </div>
                    <span className="font-black text-slate-900">{n.appName}</span>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <div className="max-w-md">
                    <p className="text-sm font-black text-slate-800 mb-1">{n.title}</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">{n.text}</p>
                  </div>
                </td>
                <td className="px-8 py-6 text-right">
                  <span className="text-xs font-black text-slate-400 uppercase tracking-tighter">
                    {format(new Date(n.timestamp), 'MMM d, HH:mm')}
                  </span>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}

function CallsView({ calls }: { calls: CallLogData[] }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-modern overflow-hidden"
    >
      <div className="p-8 border-b border-slate-50">
        <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Call Logs</h3>
        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Incoming and outgoing call history</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Contact</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Type</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Duration</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {calls.map((c, idx) => (
              <motion.tr 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                key={c.id} 
                className="hover:bg-slate-50/50 transition-colors group"
              >
                <td className="px-8 py-6">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-brand-50 transition-colors">
                      <Phone size={18} className="text-slate-400 group-hover:text-brand-600 transition-colors" />
                    </div>
                    <div>
                      <p className="font-black text-slate-900">{c.name || 'Unknown'}</p>
                      <p className="text-xs text-slate-400 font-mono font-bold">{c.number}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <span className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                    c.type === 'incoming' ? "bg-emerald-50 text-emerald-600" : 
                    c.type === 'outgoing' ? "bg-brand-50 text-brand-600" : "bg-rose-50 text-rose-600"
                  )}>
                    {c.type}
                  </span>
                </td>
                <td className="px-8 py-6">
                  <span className="text-xs font-black text-slate-600">{Math.floor(c.duration / 60)}m {c.duration % 60}s</span>
                </td>
                <td className="px-8 py-6 text-right">
                  <span className="text-xs font-black text-slate-400 uppercase tracking-tighter">
                    {format(new Date(c.timestamp), 'MMM d, HH:mm')}
                  </span>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}

function MessagesView({ messages }: { messages: MessageData[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {messages.map((m, idx) => (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: idx * 0.05 }}
          whileHover={{ y: -5 }}
          key={m.id} 
          className="card-modern p-8 group"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-rose-50 rounded-2xl flex items-center justify-center group-hover:bg-rose-100 transition-colors">
                <MessageSquare size={20} className="text-rose-600" />
              </div>
              <div>
                <p className="text-base font-black text-slate-900">{m.address}</p>
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{m.type}</p>
              </div>
            </div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">
              {format(new Date(m.timestamp), 'HH:mm')}
            </span>
          </div>
          <div className="relative">
            <Quote size={24} className="absolute -top-2 -left-2 text-slate-100 -z-10" />
            <p className="text-slate-600 text-sm leading-relaxed bg-slate-50 p-5 rounded-2xl font-medium italic">
              "{m.body}"
            </p>
          </div>
        </motion.div>
      ))}
      {messages.length === 0 && (
        <div className="col-span-full py-32 text-center card-modern flex flex-col items-center justify-center">
          <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
            <MessageSquare size={40} className="text-slate-200" />
          </div>
          <h3 className="text-xl font-black text-slate-900 mb-2">No messages found</h3>
          <p className="text-slate-400 font-bold">Waiting for device SMS logs...</p>
        </div>
      )}
    </div>
  );
}

function LocationView({ locations, device }: { locations: LocationData[], device: Device }) {
  const [refreshing, setRefreshing] = useState(false);

  const handleRefreshNow = async () => {
    setRefreshing(true);
    try {
      const deviceRef = doc(db, 'devices', device.id);
      await setDoc(deviceRef, { 
        lastLocationRequest: new Date().toISOString() 
      }, { merge: true });
      // Simulate a short delay for UI feedback
      setTimeout(() => setRefreshing(false), 2000);
    } catch (error) {
      console.error("Error requesting location refresh:", error);
      setRefreshing(false);
    }
  };

  const handleIntervalChange = async (interval: number) => {
    try {
      const deviceRef = doc(db, 'devices', device.id);
      await setDoc(deviceRef, { 
        locationRefreshInterval: interval 
      }, { merge: true });
    } catch (error) {
      console.error("Error updating refresh interval:", error);
    }
  };

  const latestLocation = locations[0];
  const refreshIntervals = [
    { label: '1 Min', value: 1 },
    { label: '5 Mins', value: 5 },
    { label: '15 Mins', value: 15 },
    { label: '30 Mins', value: 30 },
    { label: '1 Hour', value: 60 },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 card-modern p-4 min-h-[600px] relative overflow-hidden"
        >
          <div className="absolute top-8 left-8 z-10 space-y-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="glass p-8 rounded-[32px] border border-white/20 shadow-2xl max-w-xs"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-black text-slate-900 uppercase tracking-widest text-xs">Live Status</h3>
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Active</span>
                </div>
              </div>
              
              {latestLocation ? (
                <div className="space-y-6">
                  <div>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-2">Current Coordinates</p>
                    <div className="bg-slate-50 p-4 rounded-2xl">
                      <p className="font-mono text-sm text-brand-600 font-black">
                        {latestLocation.latitude.toFixed(6)}, {latestLocation.longitude.toFixed(6)}
                      </p>
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-2">Last Updated</p>
                    <p className="text-sm text-slate-700 font-black">
                      {format(new Date(latestLocation.timestamp), 'HH:mm:ss')}
                      <span className="text-slate-400 ml-2 font-bold">({format(new Date(latestLocation.timestamp), 'MMM d')})</span>
                    </p>
                  </div>
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleRefreshNow}
                    disabled={refreshing}
                    className={cn(
                      "w-full py-4 rounded-2xl font-black text-sm transition-all flex items-center justify-center gap-3 shadow-lg",
                      refreshing 
                        ? "bg-slate-100 text-slate-400 cursor-not-allowed shadow-none" 
                        : "bg-brand-600 text-white hover:bg-brand-700 shadow-brand-200"
                    )}
                  >
                    <RefreshCw size={18} className={cn(refreshing && "animate-spin")} />
                    {refreshing ? "Requesting..." : "Refresh Now"}
                  </motion.button>
                </div>
              ) : (
                <div className="py-10 text-center">
                  <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin size={24} className="text-slate-200" />
                  </div>
                  <p className="text-slate-400 font-bold">Waiting for location...</p>
                </div>
              )}
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
              className="glass p-8 rounded-[32px] border border-white/20 shadow-2xl max-w-xs"
            >
              <h3 className="font-black text-slate-900 uppercase tracking-widest text-xs mb-6">Auto-Refresh</h3>
              <div className="grid grid-cols-3 gap-3">
                {refreshIntervals.map((interval) => (
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    key={interval.value}
                    onClick={() => handleIntervalChange(interval.value)}
                    className={cn(
                      "py-3 rounded-2xl text-[10px] font-black transition-all border-2",
                      device.locationRefreshInterval === interval.value
                        ? "bg-brand-600 border-brand-600 text-white shadow-lg shadow-brand-100"
                        : "bg-white border-slate-50 text-slate-400 hover:border-brand-200 hover:text-brand-600"
                    )}
                  >
                    {interval.label}
                  </motion.button>
                ))}
              </div>
              <div className="mt-6 flex items-start gap-3 p-4 bg-amber-50 rounded-2xl">
                <Info size={16} className="text-amber-500 flex-shrink-0 mt-0.5" />
                <p className="text-[10px] text-amber-700 font-bold leading-relaxed">
                  High frequency updates may impact the child's device battery life significantly.
                </p>
              </div>
            </motion.div>
          </div>
          
          <div className="w-full h-full bg-slate-50 flex items-center justify-center rounded-[28px] border-4 border-dashed border-slate-100">
            <div className="text-center">
              <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                <MapPin size={48} className="text-brand-200" />
              </div>
              <h4 className="text-xl font-black text-slate-900 mb-2">Interactive Map View</h4>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Mapbox / Google Maps Integration</p>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card-modern p-10 flex flex-col"
        >
          <div className="flex items-center justify-between mb-10">
            <div>
              <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Movement History</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Past location breadcrumbs</p>
            </div>
            <div className="w-12 h-12 bg-brand-50 rounded-2xl flex items-center justify-center text-brand-600">
              <History size={24} />
            </div>
          </div>
          <div className="space-y-8 overflow-y-auto pr-4 custom-scrollbar flex-1">
            {locations.map((loc, i) => (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                key={loc.id} 
                className="relative pl-10 pb-8 border-l-2 border-slate-100 last:border-0 last:pb-0 group"
              >
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-white border-4 border-brand-500 shadow-lg group-hover:scale-125 transition-transform" />
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-black text-slate-900">{format(new Date(loc.timestamp), 'HH:mm')}</p>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{format(new Date(loc.timestamp), 'MMM d')}</p>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl inline-block group-hover:bg-brand-50 transition-colors">
                    <p className="text-[10px] font-mono text-brand-600 font-black">
                      {loc.latitude.toFixed(4)}, {loc.longitude.toFixed(4)}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
            {locations.length === 0 && (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
                  <History size={32} className="text-slate-200" />
                </div>
                <p className="text-slate-400 font-bold">No history available</p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function FilesView({ files }: { files: FileData[] }) {
  const images = files.filter(f => f.isImage);
  const otherFiles = files.filter(f => !f.isImage);

  return (
    <div className="space-y-12">
      {/* Gallery Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Gallery</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Photos captured on device</p>
          </div>
          <span className="px-5 py-2 bg-brand-50 text-brand-700 rounded-2xl text-xs font-black uppercase tracking-widest">
            {images.length} Photos
          </span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {images.map((img, idx) => (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              key={img.id} 
              className="group relative aspect-square bg-slate-100 rounded-[32px] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500"
            >
              <img 
                src={img.thumbnailUrl} 
                alt={img.fileName} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 backdrop-blur-sm">
                <motion.button 
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-12 h-12 bg-white rounded-2xl text-slate-900 flex items-center justify-center hover:bg-brand-600 hover:text-white transition-colors shadow-xl"
                >
                  <Eye size={20} />
                </motion.button>
                <motion.button 
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-12 h-12 bg-white rounded-2xl text-slate-900 flex items-center justify-center hover:bg-brand-600 hover:text-white transition-colors shadow-xl"
                >
                  <Download size={20} />
                </motion.button>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-slate-900/80 to-transparent">
                <p className="text-[10px] text-white font-black truncate tracking-tight">{img.fileName}</p>
              </div>
            </motion.div>
          ))}
          {images.length === 0 && (
            <div className="col-span-full py-32 text-center card-modern border-dashed border-slate-200 flex flex-col items-center justify-center">
              <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                <ImageIcon size={40} className="text-slate-200" />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2">No photos found</h3>
              <p className="text-slate-400 font-bold">The device gallery is empty</p>
            </div>
          )}
        </div>
      </motion.section>

      {/* Files Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Recent Files</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Documents and other media</p>
          </div>
          <span className="px-5 py-2 bg-slate-100 text-slate-600 rounded-2xl text-xs font-black uppercase tracking-widest">
            {otherFiles.length} Documents
          </span>
        </div>
        <div className="card-modern overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">File Name</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Size</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Type</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {otherFiles.map((f, idx) => (
                <motion.tr 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  key={f.id} 
                  className="hover:bg-slate-50/50 transition-colors group"
                >
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center group-hover:bg-brand-50 transition-colors">
                        <FileText size={22} className="text-slate-400 group-hover:text-brand-600 transition-colors" />
                      </div>
                      <div>
                        <p className="font-black text-slate-900">{f.fileName}</p>
                        <p className="text-[10px] text-slate-400 font-mono font-bold truncate max-w-xs">{f.filePath}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="text-xs font-black text-slate-600">{(f.fileSize / 1024 / 1024).toFixed(2)} MB</span>
                  </td>
                  <td className="px-8 py-6">
                    <span className="px-3 py-1 bg-slate-100 text-slate-600 text-[10px] font-black rounded-lg uppercase tracking-widest">
                      {f.mimeType.split('/')[1]}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <motion.button 
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="w-10 h-10 bg-slate-50 text-brand-600 hover:bg-brand-600 hover:text-white rounded-xl flex items-center justify-center transition-colors shadow-sm"
                    >
                      <Download size={18} />
                    </motion.button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
          {otherFiles.length === 0 && (
            <div className="py-32 text-center flex flex-col items-center justify-center">
              <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                <FileText size={40} className="text-slate-200" />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2">No documents found</h3>
              <p className="text-slate-400 font-bold">Waiting for file system scan...</p>
            </div>
          )}
        </div>
      </motion.section>
    </div>
  );
}

function AppsView({ apps, installRequests, deviceId }: { apps: AppData[], installRequests: InstallRequest[], deviceId: string }) {
  const [showInstallModal, setShowInstallModal] = useState(false);
  const [installUrl, setInstallUrl] = useState('');
  const [installName, setInstallName] = useState('');

  const toggleAppStatus = async (app: AppData) => {
    try {
      const appRef = doc(db, `devices/${deviceId}/apps`, app.id);
      await setDoc(appRef, { isBlocked: !app.isBlocked }, { merge: true });
    } catch (error) {
      console.error("Error toggling app status:", error);
    }
  };

  const handleRemoteInstall = async (name: string, url: string) => {
    try {
      await addDoc(collection(db, `devices/${deviceId}/installRequests`), {
        deviceId,
        appName: name,
        apkUrl: url,
        status: 'pending',
        timestamp: new Date().toISOString()
      });
      setShowInstallModal(false);
      setInstallUrl('');
      setInstallName('');
    } catch (error) {
      console.error("Error creating install request:", error);
    }
  };

  const curatedApps = [
    { name: "Khan Academy Kids", url: "https://example.com/khan_kids.apk", icon: "🎓" },
    { name: "Duolingo ABC", url: "https://example.com/duolingo_abc.apk", icon: "🦉" },
    { name: "Safe Search Browser", url: "https://example.com/safe_browser.apk", icon: "🌐" },
  ];

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Installed Apps</h3>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Manage device applications</p>
        </div>
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowInstallModal(true)}
          className="flex items-center gap-3 px-8 py-4 bg-brand-600 text-white rounded-2xl font-black hover:bg-brand-700 transition-all shadow-xl shadow-brand-100"
        >
          <Plus size={20} />
          Remote Install
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {apps.map((app, idx) => (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.05 }}
            key={app.id} 
            className="card-modern p-8 group"
          >
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-slate-50 rounded-2xl overflow-hidden border border-slate-100 flex items-center justify-center group-hover:scale-110 transition-transform">
                  {app.iconUrl ? (
                    <img src={app.iconUrl} alt={app.appName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <AppWindow size={28} className="text-slate-300" />
                  )}
                </div>
                <div>
                  <h4 className="text-lg font-black text-slate-900">{app.appName}</h4>
                  <p className="text-[10px] text-slate-400 font-mono font-bold truncate max-w-[120px]">{app.packageName}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[10px] font-black rounded uppercase">v{app.version}</span>
                  </div>
                </div>
              </div>
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                app.isBlocked ? "bg-rose-50 text-rose-600" : "bg-emerald-50 text-emerald-600"
              )}>
                {app.isBlocked ? <Lock size={20} /> : <Unlock size={20} />}
              </div>
            </div>

            <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl mb-6">
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Status</span>
                <span className={cn(
                  "text-sm font-black uppercase tracking-wider",
                  app.isBlocked ? "text-rose-600" : "text-emerald-600"
                )}>
                  {app.isBlocked ? "Blocked" : "Allowed"}
                </span>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => toggleAppStatus(app)}
                className={cn(
                  "px-8 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all shadow-md",
                  app.isBlocked 
                    ? "bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-100" 
                    : "bg-rose-600 text-white hover:bg-rose-700 shadow-rose-100"
                )}
              >
                {app.isBlocked ? "Unblock" : "Block"}
              </motion.button>
            </div>
            
            <div className="flex items-center gap-2 text-[10px] text-slate-400 font-black uppercase tracking-widest">
              <Clock size={12} />
              Last used: {format(new Date(app.lastUsed), 'MMM d, HH:mm')}
            </div>
          </motion.div>
        ))}
      </div>

      {installRequests.length > 0 && (
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-16"
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">Installation Requests</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Remote app deployment status</p>
            </div>
            <div className="w-12 h-12 bg-brand-50 rounded-2xl flex items-center justify-center text-brand-600">
              <DownloadCloud size={24} />
            </div>
          </div>
          <div className="card-modern overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50">
                  <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">App Name</th>
                  <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                  <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {installRequests.map((req, idx) => (
                  <motion.tr 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    key={req.id}
                  >
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center">
                          <Package size={18} className="text-brand-400" />
                        </div>
                        <span className="font-black text-slate-900">{req.appName}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className={cn(
                        "px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest",
                        req.status === 'completed' ? "bg-emerald-50 text-emerald-600" :
                        req.status === 'failed' ? "bg-rose-50 text-rose-600" : "bg-brand-50 text-brand-600 animate-pulse"
                      )}>
                        {req.status}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-right text-xs font-black text-slate-400 uppercase tracking-tighter">
                      {format(new Date(req.timestamp), 'MMM d, HH:mm')}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.section>
      )}

      <AnimatePresence>
        {showInstallModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowInstallModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-[40px] w-full max-w-2xl overflow-hidden shadow-2xl relative z-10"
            >
              <div className="p-10 bg-brand-600 text-white relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-3xl font-black font-display tracking-tight mb-2">Remote App Install</h3>
                  <p className="text-brand-100 font-medium">Deploy educational or safe apps to the child's device.</p>
                </div>
                <DownloadCloud size={120} className="absolute -right-8 -bottom-8 text-white/10" />
              </div>
              
              <div className="p-10 space-y-10">
                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Curated Safe Apps</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {curatedApps.map((app) => (
                      <motion.button
                        whileHover={{ y: -5, scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        key={app.name}
                        onClick={() => handleRemoteInstall(app.name, app.url)}
                        className="p-6 bg-slate-50 rounded-3xl border-2 border-transparent hover:border-brand-200 hover:bg-brand-50 transition-all text-left group"
                      >
                        <span className="text-3xl mb-4 block group-hover:scale-110 transition-transform">{app.icon}</span>
                        <p className="font-black text-slate-900 text-sm group-hover:text-brand-600 leading-tight mb-1">{app.name}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Safe App</p>
                      </motion.button>
                    ))}
                  </div>
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t-2 border-slate-50"></span>
                  </div>
                  <div className="relative flex justify-center text-[10px] uppercase tracking-widest">
                    <span className="bg-white px-6 text-slate-400 font-black">Or provide custom APK</span>
                  </div>
                </div>

                <div className="space-y-5">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">App Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Minecraft Education"
                      value={installName}
                      onChange={(e) => setInstallName(e.target.value)}
                      className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl focus:border-brand-500 focus:bg-white transition-all font-bold text-slate-900 outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Direct APK URL</label>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="https://example.com/app.apk"
                        value={installUrl}
                        onChange={(e) => setInstallUrl(e.target.value)}
                        className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl focus:border-brand-500 focus:bg-white transition-all font-bold text-slate-900 outline-none"
                      />
                      <ExternalLink size={18} className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-300" />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setShowInstallModal(false)}
                    className="flex-1 py-5 bg-slate-100 text-slate-600 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-slate-200 transition-colors"
                  >
                    Cancel
                  </motion.button>
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleRemoteInstall(installName, installUrl)}
                    disabled={!installName || !installUrl}
                    className="flex-1 py-5 bg-brand-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-brand-700 transition-all shadow-xl shadow-brand-100 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Send Request
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SetupGuideView() {
  const steps = [
    {
      title: "Download the Child App",
      description: "Download the GuardianLink Companion APK on the child's Android device.",
      icon: DownloadCloud,
      color: "bg-blue-500",
      accent: "bg-blue-50"
    },
    {
      title: "Grant Permissions",
      description: "Enable Notification Access, Device Admin, and Accessibility Services to allow full monitoring and blocking.",
      icon: ShieldCheck,
      color: "bg-brand-500",
      accent: "bg-brand-50"
    },
    {
      title: "Pair with Dashboard",
      description: "Scan the QR code or enter your Parent ID on the child's device to link it to this dashboard.",
      icon: Smartphone,
      color: "bg-purple-500",
      accent: "bg-purple-50"
    },
    {
      title: "Secure the App",
      description: "Enable 'Anti-Uninstall' in the child app settings to prevent the child from removing it.",
      icon: Lock,
      color: "bg-rose-500",
      accent: "bg-rose-50"
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-brand-600 rounded-[40px] p-12 text-white shadow-2xl shadow-brand-200 relative overflow-hidden"
      >
        <div className="relative z-10">
          <h2 className="text-4xl font-black font-display tracking-tight mb-6">How to set up GuardianLink</h2>
          <p className="text-brand-100 text-xl max-w-2xl leading-relaxed font-medium">
            Follow these steps to connect your child's Android device to your dashboard. This process takes about 5 minutes.
          </p>
        </div>
        <HelpCircle size={180} className="absolute -right-12 -bottom-12 text-white/10" />
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {steps.map((step, i) => (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            whileHover={{ y: -5 }}
            key={i} 
            className="card-modern p-10 flex gap-8 items-start group"
          >
            <div className={cn("w-20 h-20 rounded-3xl text-white flex-shrink-0 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform", step.color)}>
              <step.icon size={36} />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className="px-3 py-1 bg-slate-100 text-slate-600 text-[10px] font-black uppercase tracking-widest rounded-lg">Step {i + 1}</span>
                <CheckCircle2 size={16} className="text-emerald-500" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-3 tracking-tight">{step.title}</h3>
              <p className="text-slate-500 leading-relaxed font-medium">{step.description}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-amber-50 border-2 border-amber-100 rounded-[32px] p-10 flex gap-8 items-start"
      >
        <div className="w-16 h-16 bg-amber-500 rounded-2xl text-white flex items-center justify-center flex-shrink-0 shadow-lg shadow-amber-200">
          <Info size={32} />
        </div>
        <div>
          <h4 className="text-2xl font-black text-amber-900 mb-4 tracking-tight">Important Technical Note</h4>
          <p className="text-amber-800 leading-relaxed font-medium text-lg">
            To monitor notifications, call logs, and messages, the Android app must be built using the **NotificationListenerService** and **DevicePolicyManager** APIs. For app blocking, **AccessibilityService** is required. These are advanced Android features that ensure the app remains persistent and secure.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
